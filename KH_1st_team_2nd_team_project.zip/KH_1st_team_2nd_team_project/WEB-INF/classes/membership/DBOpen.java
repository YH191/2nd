package membership;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBOpen {
	
	public static Connection getConnection() throws Exception{
		//static -> 클래스명으로 직접 접근 가능하다.
	
		Class.forName("oracle.jdbc.OracleDriver");
		Connection con = DriverManager.getConnection ("jdbc:oracle:thin:@//localhost:1521/xe","kh1stteam","1234");
		return con;		
	}			
}//getConnetion end