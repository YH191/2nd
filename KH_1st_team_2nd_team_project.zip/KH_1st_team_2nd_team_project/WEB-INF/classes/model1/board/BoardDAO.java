package model1.board;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.servlet.ServletContext;

import common.JDBConnect;
import membership.DBOpen;

public class BoardDAO extends JDBConnect{
	public BoardDAO(ServletContext application) {
		super(application);
	}
	//검색 조건에 맞는 게시물의 개수를 반환합니다.
	public int selectCount(Map<String, Object> map) {
		int totalCount = 0;//결과(게시물 수)를 담을 변수
		
		//게시물 수를 얻어오는 쿼리문 작성
		String query = "SELECT COUNT(*) FROM khmallmvcboard";
		if(map.get("searchWord") != null){
				query += "WHERE" + map.get("searchField")+ " "
					+ " LIKE '%" + map.get("searchWord") +"%' ";
	}
		try {
			stmt = con.createStatement(); //쿼리문 생성
			rs = stmt.executeQuery(query); //쿼리 실행
			rs.next(); //커서를 첫 번째 행으로 이동
			totalCount = rs.getInt(1); //첫 번째 컬럼 값을 가져옴
		}
		catch(Exception e) {
			System.out.println("게시물 수를 구하는 중 예외 발생");
			e.printStackTrace();
		}
		return totalCount;
	}
	//검색 조건에 맞는 게시물 목록을 반환함
	public List<BoardDTO> selectList(Map<String, Object> map){
		List<BoardDTO> bbs = new Vector<BoardDTO>();
		//결과(게시물 목록)을 담을 변수
		
		String query = "SELECT * FROM khmallmvcboard ";
		if (map.get("searchWord") != null) {
			query += "WHERE " + map.get("searchField")+" "
					+" LIKE '%" + map.get("searchWord") +"%' ";
		}
		query += " ORDER BY idx DESC ";
		
		try {
			stmt = con.createStatement(); //쿼리문 생성
			rs = stmt.executeQuery(query); //쿼리 실행
			
			while (rs.next()) {//결과를 순화하며 한 행(게시물 하나)의 내용을 DTO에 저장
				BoardDTO dto = new BoardDTO();
				//일련번호, 제목, 내용, 작성일, 작성자 아이디, 조회수
				dto.setNum(rs.getString("idx")); 
				dto.setTitle(rs.getString("title"));
				dto.setContent(rs.getString("content"));
				dto.setPostdate(rs.getDate("postdate"));
				dto.setId(rs.getString("id"));
				dto.setVisitcount(rs.getString("visitcount"));
				
				bbs.add(dto); //결과 목록에 저장
			}
		}
		catch(Exception e) {
			System.out.println("게시물 조회 중 예외 발생");
			e.printStackTrace();
		}
		return bbs;
		}
//20220314
	//검색 조건에 맞는 게시물 목록을 반환합니다(페이징 기능 지원)
	public List<BoardDTO> selectListPage(Map<String, Object> map){
		List<BoardDTO> bbs = new Vector<BoardDTO>();
		//결과(게시물 목록)을 담을 변수
		//쿼리문 템플릿
		String query = " SELECT * FROM ( "
					+ "   SELECT Tb.*, ROWNUM rNum FROM ( "
					+ "    SELECT * FROM khmallmvcboard ";
		//검색 조건 추가
		if(map.get("searchWord") != null) {
			query += " WHERE " + map.get("searchField")
					+ " LIKE '%"+map.get("searchWord")+"%' ";
		}
		query += "  ORDER BY num DESC "
				+ " ) Tb "
				+ " ) "
				+ " WHERE rNUM BETWEEN ? AND ?";
		try {
			//쿼리문 완성
			psmt = con.prepareStatement(query);
			psmt.setString(1, map.get("start").toString());
			psmt.setString(2, map.get("end").toString());
			
			//쿼리문 실행
			rs = psmt.executeQuery();
			while(rs.next()) {
				//한 행의 데이터를 DTO에 저장
				BoardDTO dto = new BoardDTO();
				dto.setNum(rs.getString("num"));
				dto.setTitle(rs.getString("title"));
				dto.setContent(rs.getString("content"));
				dto.setPostdate(rs.getDate("postdate"));
				dto.setId(rs.getString("id"));
				dto.setVisitcount(rs.getString("visitcount"));
				
				//반환할 결과 목록에 게시물 추가
				bbs.add(dto);
			}
		}
		catch(Exception e) {
			System.out.println("게시물 조회 중 예외 발생");
			e.printStackTrace();
		}
		//목록 반환
		return bbs;
		
	}
//20220314
	
	//게시글 데이터를 받아 DB에 추가합니다
	public int insertWrite(BoardDTO dto) {
		int result = 0;
		
		try {
			//INSERT쿼리문 작성
			String query = "INSERT INTO khmallmvcboard ( "
							+ " idx, title, content, id, name, pass, visitcount)"
							+ " VALUES ( "
							+ " seq_board_num.NEXTVAL, ?, ?, ?, ?, ?, 0)";
			
			psmt = con.prepareStatement(query); //동적 쿼리
			psmt.setString(1, dto.getTitle());
			psmt.setString(2, dto.getContent());
			psmt.setString(3, dto.getId());
			psmt.setString(4, dto.getName());
			psmt.setString(5, dto.getPass());
			
			result = psmt.executeUpdate();
		}
		catch(Exception e) {
			System.out.println("게시물 입력 중 예외 발생");
			e.printStackTrace();
		}
		return result;
	}
	//지정된 게시물을 찾아 내용을 반환함
	public BoardDTO selectView(String num) {
		BoardDTO dto = new BoardDTO();
		
//		쿼리문 준비
		String query = "SELECT B.*, name "
						+ " FROM member M INNER JOIN khmallmvcboard B "
						+ " On M.id=B.id "
						+ " WHERE num=?";
		try {
			psmt = con.prepareStatement(query);
			psmt.setString(1, num); //인파라미터를 일련번호로 설정
			rs = psmt.executeQuery(); //쿼리 실행
			
			//결과 처리
			if(rs.next()) {
				dto.setNum(rs.getString(1));
				dto.setTitle(rs.getString(2));
				dto.setContent(rs.getString("content"));
				dto.setPostdate(rs.getDate("postdate"));
				dto.setId(rs.getString("id"));
				dto.setVisitcount(rs.getString(6));
				dto.setName(rs.getString("name"));
			}
		}
		catch(Exception e) {
			System.out.println("게시물 상세보기 중 예외 발생");
			e.printStackTrace();
		}
		return dto;
	}
//	지정한 게시물의 조회수를 1 증가시킴
	public void updateVisitCount(String num) {
//		쿼리문 준비
		String query = "UPDATE board SET "
					+ " visitcount=visitcount+1 "
					+ " WHERE num=?";
		try {
			psmt = con.prepareStatement(query);
			psmt.setString(1, num);//인파라미터를 일련번호로 설정
			psmt.executeQuery();//쿼리 실행
		}
		catch(Exception e) {
			System.out.println("게시물 조회수 증가 중 예외 발생");
			e.printStackTrace();
		}
	}
	//지정한 게시물을 수정함.
	public int updateEdit(BoardDTO dto) {
		int result=0;
		try {
			//쿼리문 템플릿
			String query = "UPDATE khmallmvcboard SET "
						+ " title=?, content=? "
						+ " WHERE num=? ";
			
			//쿼리문 완성
			psmt = con.prepareStatement(query);
			psmt.setString(1, dto.getTitle());
			psmt.setString(2, dto.getContent());
			psmt.setString(3, dto.getNum());
			
			//쿼리문 실행
			result = psmt.executeUpdate();
		}
		catch (Exception e) {
			System.out.println("게시물 수정 중 예외 발생");
			e.printStackTrace();
		}
		return result; //결과 반환
	}
	//지정한 게시물을 삭제함
	public int deletePost(BoardDTO dto) {
		int result = 0;
		
		try {
			//쿼리문 템플릿
			String query = "DELETE FROM khmallmvcboard WHERE num=?";
			
			//쿼리문 완성
			psmt = con.prepareStatement(query);
			psmt.setString(1, dto.getNum());
			
			//쿼리문 실행
			result = psmt.executeUpdate();
		}
		catch (Exception e) {
			System.out.println("게시물 삭제 중 예외 발생");
			e.printStackTrace();
		}
		return result; //결과 반환
	}
	
	//회원가입용 쿼리
	public int join(BoardDTO dto) {
		int result=0;
		
		try {
			//쿼리문 템플릿
			String query = "Insert into member(name, id, pass, email, pnum, authority, addr, regidate) values( "
						+ " ?, ?, ?, ?, ?, '회원', ?, sysdate) ";
			
			//쿼리문 완성
			psmt = con.prepareStatement(query);
			psmt.setString(1, dto.getName());
			psmt.setString(2, dto.getId());
			psmt.setString(3, dto.getPass());
			psmt.setString(4, dto.getEmail());
			psmt.setString(5, dto.getPnum());
			psmt.setString(6, dto.getAddr());
			
			//쿼리문 실행
			result = psmt.executeUpdate();
		}
		catch (Exception e) {
			System.out.println("회원가입 중 예외 발생");
			e.printStackTrace();
		}
		return result; //결과 반환
	}
	
	//회원수정용 쿼리
		public int update(BoardDTO dto) {
			int result=0;
			
			try {
				//쿼리문 템플릿
				String query = "update member set "
							+ " name=?, pass=?, pnum=?, email=? "
							+ " where id=?";
				
				//쿼리문 완성
				psmt = con.prepareStatement(query);
				psmt.setString(1, dto.getName());
				psmt.setString(2, dto.getPass());
				psmt.setString(3, dto.getPnum());
				psmt.setString(4, dto.getEmail());
				psmt.setString(5, dto.getId());
				
				//쿼리문 실행
				result = psmt.executeUpdate();
			}
			catch (Exception e) {
				System.out.println("회원정보 수정 중 예외 발생");
				e.printStackTrace();
			}
			return result; //결과 반환
		}
		
		//회원가입 중복 확인용
		public int duplecateID(String id){ 
			int cnt=0; 
			try{ 
				Connection	con= DBOpen.getConnection();
				StringBuilder sql=new StringBuilder(); //아이디 중복 확인 
				sql.append(" SELECT count(id) as cnt "); 
				sql.append(" FROM member "); 
				sql.append(" WHERE id = ? "); 
				PreparedStatement pstmt=con.prepareStatement(sql.toString());
				pstmt.setString(1, id);
				ResultSet rs=pstmt.executeQuery(); 
				if(rs.next()){ 
					cnt=rs.getInt("cnt");
					} 
				}catch(Exception e){
					System.out.println("아이디 중복 확인 실패 : " + e);
				}//try end 
			return cnt;
			}//duplecateID end
		
		//id찾기용 메소드
		public String findId(String name, String pnum) {
			String mid = null;
			
			try {
				String sql = "select id from member where name=? and pnum=? ";
				psmt = con.prepareStatement(sql);
				psmt.setString(1, name);
				psmt.setString(2, pnum);
				
				rs = psmt.executeQuery();
				
				if(rs.next()) {
					mid = rs.getString("id");
				}
					
			} catch (Exception e) {
				e.printStackTrace();
			}
			return mid;
		}
		
		//pass찾기용 메소드
		public String findPass(String id, String pnum) {
			String mid = null;
			
			try {
				String sql = "select pass from member where id=? and pnum=? ";
				psmt = con.prepareStatement(sql);
				psmt.setString(1, id);
				psmt.setString(2, pnum);
				
				rs = psmt.executeQuery();
				
				if(rs.next()) {
					mid = rs.getString("pass");
				}
					
			} catch (Exception e) {
				e.printStackTrace();
			}
			return mid;
		}
			
	}

//executeUpdate()로 DML 수행 시 적용된 행의 개수를 반환합니다
//그래서 인서트로 데이터 입력하면 1개 행 추가되서 1 반환
//executeQuery()는 ResultSet 객체인 rs 변수에 
//executeQuery() 값을 저장하는 반면
//executeUpdate()는 값을 저장하지 않고 바로 호출하는 코드로 작성된다
//executeQuery
//rs = prepare.excuteQuery에서 executeQuery는
//PreparedStatement를 통해 SQL을 실행한 값을 ResultSet에 전달하는 역할을 맡았다
//그러므로 ResultSet객체를 생성한 변수 rs에 저장을 한번 해준 것이고
//커서 단위로 값을 출력하는 ResultSet의 특징을 사용해
//원하는 SQL값을 rs변수를 통해 출력할 수 있다
//executeUpdate
//PreparedStatement 객체를 통해 SQL을 실행하는 것은 executeQuery와 동일 합니다.
//다만 execute의 Update는 DBMS에서 DDL 개념으로 이해
//DML은 추가, 삭제, 수정 기능의 insert, update, delete 기능이 있습니다
//3가지 기능은 아무런 값도 돌려주지 않고 바로 SQL문에 
//추가, 삭제, 수정을 하면 되기 때문에 prepare.executeUpdate를 사용할 때는 
//특정한 곳에 값을 저장하는 개념이 아닌 바로 명령문을 실행하고 
//실행한 코드는 더 이상의 역할을 갖지 않는 것으로 이해하면 될 것 같습니다
//DDL 은 create,drop,alter
//executeUpdate 는 행의 갯수가 없을때는 0으로 나옵니다 