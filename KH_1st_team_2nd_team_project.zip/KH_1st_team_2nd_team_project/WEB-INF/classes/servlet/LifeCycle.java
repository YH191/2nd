package servlet;

import java.io.IOException;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/13Servlet/LifeCycle.do")
public class LifeCycle extends HttpServlet {
	@PostConstruct
	public void myPostConstruct() {//1
		System.out.println("myPostConstruc() 호출");
	}
	@Override
	public void init() throws ServletException {//2
		System.out.println("init() 호출");
	}
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException{//3 //1
		System.out.println("service() 호출");
		super.service(req, resp);
	}
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException{//4 
		System.out.println("doGet() 호출");
		req.getRequestDispatcher("/13Servlet/LifeCycle.jsp").forward(req, resp);
	}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException{//2
		System.out.println("doPost() 호출");//처리속도를 높여줌
		req.getRequestDispatcher("/13Servlet/LifeCycle.jsp").forward(req, resp);
	}
	@Override
	public void destroy() {//메모리에서 소멸시킴,톰캣을 종료시에 나타남
		System.out.println("destroy() 호출");
	}
	@PreDestroy
	public void myPreDestroy() {//2 Destory
		System.out.println("myPreDestory() 호출");
	}
}
