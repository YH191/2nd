package dao;

import java.util.ArrayList;

import dto.Product;

public class ProductRepository {
	// 통합 저장소 컬렉션 리스트
	private ArrayList<Product> listOfProducts = new ArrayList<Product>();

	private static ProductRepository instance = new ProductRepository();

	public static ProductRepository getInstance() {
		return instance;
	}

	// 생성자
	public ProductRepository() {
		// phone 제품 객체 생성하여 각 데이터 저장
		Product phone1 = new Product("P1234", "iPhone 12", 1200000);
		phone1.setDescription("146.7*71.5*7.4mm, Super Retina XDR display, " + "Apple A14 Bionic (5 nm)");
		phone1.setCategory("Smart Phone");
		phone1.setManufacturer("Apple");
		phone1.setUnitsInStock(1000);
		phone1.setCondition("New");
		phone1.setFilename("P1234.png");

		// notebook 제품 객체 생성하여 각 데이터 저장
		Product notebook1 = new Product("P1235", "LG gram", 1500000);
		notebook1.setDescription("13.3-inch, IPS LED display, " + "5rdGeneration Intel Core Processors");
		notebook1.setCategory("Notebook");
		notebook1.setManufacturer("LG");
		notebook1.setUnitsInStock(1000);
		notebook1.setCondition("Refurbished");
		notebook1.setFilename("P1235.png");

		// tablet 제품 객체 생성하여 각 데이터 저장
		Product tablet1 = new Product("P1236", "Galaxy Tab s8", 900000);
		tablet1.setDescription("212.8*125.6*6.6mm, Super AMOLED display, " + "Octa-Core processor");
		tablet1.setCategory("Tablet");
		tablet1.setManufacturer("Samsung");
		tablet1.setUnitsInStock(1000);
		tablet1.setCondition("Old");
		tablet1.setFilename("P1236.png");

		// 제품 객체 생성하여 데이터에 저장
		
	    Product watch1 = new Product("P1237", "Apple Watch 7", 460000); 
	    watch1.setDescription("디스플레이 면적 977mm², Force Touch가 적용된 LTPO OLED Retina 디스플레이, " +
	    "GPS + Cellular 모델"); 
	    watch1.setCategory("Watch");
	    watch1.setManufacturer("Apple"); 
	    watch1.setUnitsInStock(320);
	    watch1.setCondition("New"); 
	    watch1.setFilename("P1237.png");

	    Product watch2 = new Product("P1238", "Galaxy watch 4", 359000); 
	    watch2.setDescription("41.9*45.7*12.7 mm, Circular Super AMOLED (360 x 360), " + "Exynos 9110 Dual core 1.15GHz"); 
	    watch2.setCategory("Watch");
	    watch2.setManufacturer("Samsung"); 
	    watch2.setUnitsInStock(655);
	    watch2.setCondition("New"); 
	    watch2.setFilename("P1238.png");
	    
		Product notebook2 = new Product("P1239", "Mac book 13-inch", 2690000);
		notebook2.setDescription("13.3 in (340 mm), Retina display, " + "Apple M1 chip with 8-core CPU and 8-core GPU");
		notebook2.setCategory("Notebook");
		notebook2.setManufacturer("Apple");
		notebook2.setUnitsInStock(592);
		notebook2.setCondition("Refurbished");
		notebook2.setFilename("P1239.png");

		Product tablet2 = new Product("P1240", "Ipad Pro 11-inch", 1379000);
		tablet2.setDescription("247.6mm*178.5mm*5.9mm, Liquid Retina display, " + "Octa-core Apple CPU and Octa-core GPU");
		tablet2.setCategory("Tablet");
		tablet2.setManufacturer("Apple");
		tablet2.setUnitsInStock(68);
		tablet2.setCondition("Old");
		tablet2.setFilename("P1240.png");

		Product phone2 = new Product("P1241", "Galaxy Note 20", 900000);
		phone2.setDescription("161.6*75.2*8.3mm,  Infinity-O Display, " + "	Exynos : Mali-G77 MP11 - Global");
		phone2.setCategory("Smart Phone");
		phone2.setManufacturer("Samsung");
		phone2.setUnitsInStock(529);
		phone2.setCondition("New");
		phone2.setFilename("P1241.png");
		
		
		  
		// 생성한 각 객체를 통합 저장소 컬렉션 리스트에 저장
		
		    listOfProducts.add(phone1);			// 아이폰 12
		    listOfProducts.add(notebook1);		// LG gram
			listOfProducts.add(tablet1);		// Galaxy tab s8
			listOfProducts.add(watch1); 		// Apple watch 7
			listOfProducts.add(watch2); 		// Galaxy watch 4
			listOfProducts.add(notebook2); 		// 맥북 13인치
			listOfProducts.add(tablet2); 		// 아이패드 11인치
			listOfProducts.add(phone2);			// 갤럭시 노트 20
		 
	}

	// 통합 저장소에 저장된 모든 데이터를 컬렉션 리스트 통째로 반환하는 메서드
	public ArrayList<Product> getAllProducts() {
		return listOfProducts;
	}

	// 상품 상세 정보를 가져오는 메소드를 추가
	public Product getProductById(String productId) {
		Product productById = null; // 반환 값 넣을 변수 생성 및 초기화

		// 통합 저장소 컬렉션 리스트의 데이터 개수만큼 반복
		for (int i = 0; i < listOfProducts.size(); i++) {
			// 검사할 데이터 담을 임시 변수 생성 및 리스트의 i번째 데이터 저장
			Product product = listOfProducts.get(i);
			// 저장한 데이터가 비어있지 않고, 해당 데이터의 productId가 비어있지 않고, 해당 데이터의 productId와 전달받은
			// productId가 같으면
			if (product != null && product.getProductId() != null && product.getProductId().equals(productId)) {
				// 반환 값 넣을 변수에 해당 데이터를 저장 후
				productById = product;
				break; // 반복문을 탈출한다
			} // listOfProducts에 저장된 모든 상품 목록에서 상품 아이디와 일치하는 상품을 가져온다
		}
		// 저장한 데이터를 반환한다
		return productById;
	}

	public void addProduct(Product product) {
		listOfProducts.add(product);
	}
}